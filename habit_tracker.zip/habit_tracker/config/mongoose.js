const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://Satish1205:Satish1205@cluster0.rh0kv.mongodb.net/contactList?retryWrites=true&w=majority');


const db = mongoose.connection;
db.on('error', console.error.bind(console, 'Error on connecting moongoos:'));
//after connection 
db.once('open', function() {
  console.log("successfully connected to database");
});
