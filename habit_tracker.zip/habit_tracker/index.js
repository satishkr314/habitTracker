const express=require('express');
const path=require('path');
const port=8000;
app=express();
app.set('view engine','ejs');
app.set('views',path.join(__dirname,'views'));
const Activity=require('./models/activity');
const ActivityDetail=require('./models/activityDetail');
const db=require('./config/mongoose');
app.use(express.urlencoded());
app.use(express.static('assets'));
app.get('/',function(req,res)           //first page 
{
    Activity.find({},function(err,activities)
    {
        if(err)
        {
            console.log("Error in fatching Activities from database");
            return;
        }
        console.log("activities", activities);
        return res.render('home',{title:"activityTracker",activity:activities});
    });
    
});
app.post('/recive_input',function(req,res)    // Adding data in Habit List
{
    
    Activity.create({task:req.body.task},function(err,newActivity)
        {
            if(err)
            {
                console.log("Error in adding data");
                return;
            }
            console.log(newActivity);
            return res.redirect('/');
        });

});
app.get('/delete-task',function(req,res)    // Deleting Data from habit list
{
    var id=req.query.id;
    Activity.findByIdAndDelete(id,function(err)
    {
        if(err)
        {
            console.log("Error in Deleting Element",err);
            return res.redirect('/');
        }
        return res.redirect('/');
    })
});
app.get('/profile',function(req,res) // 2nd page of getting status of clicked habit
{
    var today = new Date();
    var habit=req.query.task;
    console.log(habit);
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    var count=0;
    ActivityDetail.find({},function(err,ActivityDtl)
    {
        console.log("Enter1");
        if(err)
        {
            console.log("error");
            return res.redirect('/');
        }
        
    
    for(var i of ActivityDtl)
    {
        console.log(i.habitName+" "+habit);
        if(i.habitName==habit)
        {
           return res.render('profile',{title:"details",tday:today,habit_track:habit,actdtl:ActivityDtl});
        }
        console.log("Enter2");
        count++;
    }
    console.log(count," ",ActivityDetail.length," ",ActivityDtl.length);
    if(count==ActivityDtl.length)
    {
        console.log("Enter3");
        var day1 =today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
        var day2 =today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
        var day3 =today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
        var day4 =today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
        var day5 =today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
        var day6 =today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
        var day7 =today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
        ActivityDetail.create({habitName:habit,Datedtl:day1},function(err,newActivity)
        {
            if(err)
            {
                console.log("Error in adding data");
                return;
            }
            console.log("Hello",newActivity);
        });
        ActivityDetail.create({habitName:habit,Datedtl:day2,undone:""},function(err,newActivity)
        {
            if(err)
            {
                console.log("Error in adding data");
                return;
            }
        });
        ActivityDetail.create({habitName:habit,Datedtl:day3,undone:""},function(err,newActivity)
        {
            if(err)
            {
                console.log("Error in adding data");
                return;
            }
        });
        ActivityDetail.create({habitName:habit,Datedtl:day4,undone:""},function(err,newActivity)
        {
            if(err)
            {
                console.log("Error in adding data");
                return;
            }
        });
        ActivityDetail.create({habitName:habit,Datedtl:day5,undone:""},function(err,newActivity)
        {
            if(err)
            {
                console.log("Error in adding data");
                return;
            }
        });
        ActivityDetail.create({habitName:habit,Datedtl:day6,undone:""},function(err,newActivity)
        {
            if(err)
            {
                console.log("Error in adding data");
                return;
            }
        });
        ActivityDetail.create({habitName:habit,Datedtl:day7,undone:""},function(err,newActivity)
        {
            if(err)
            {
                console.log("Error in adding data");
                return;
            }
        });
    }
     res.render('profile',{title:"details",tday:today,habit_track:habit,actdtl:ActivityDtl});
     return res.render('profile',{title:"details",tday:today,habit_track:habit,actdtl:ActivityDtl});

    });
    
});
app.post('/getData',function(req,res) // updating done and undone part in 2nd page
{
    
    var today=new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    var id=req.query.id;
    console.log(id);
    ActivityDetail.find({},function(err,ActivityDtl)
    {
        for(var i of ActivityDtl)
        {
            console.log(i.id);
            if(i.id==id)
            {
                console.log("id found");
                i.undone="done";
                return res.redirect('back');
                return res.render('profile',{title:"details",tday:today,habit_track:i.habitName,actdtl:ActivityDtl});

            }
        }
        console.log("id not found");
    })

    
        

});
app.post('/profile/getData2',function(req,res) // updating done and undone part in 2nd page
{
    
    var today=new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    var id=req.query.id;
    console.log(id);
    ActivityDetail.find({},function(err,ActivityDtl)
    {
        for(var i of ActivityDtl)
        {
            console.log(i.id);
            if(i.id==id)
            {
                console.log("id found");
                i.undone="Note Done";
                return res.render('profile',{title:"details",tday:today,habit_track:i.habitName,actdtl:ActivityDtl});

            }
        }
        console.log("id not found");
        //return res.render('/');
    })

    
        

});

    

app.listen(port,function(err)
{
    if(err)
    {
        console.log("Error in loading server",err);
    }
    console.log("Server is up and running at port",port);
})