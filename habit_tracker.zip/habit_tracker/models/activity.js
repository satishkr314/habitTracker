const mongoose=require('mongoose');
const activitySchema=new mongoose.Schema(
    {
        task:{
            type:String,
            requried:true
        },
        undone:{
            type:String,
            requried:true
        },
        partial:
        {
            type:String
        },
        full:
        {
            type:String
        }

    }
);
const Activity=mongoose.model('Activity',activitySchema);
module.exports=Activity;