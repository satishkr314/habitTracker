const mongoose=require('mongoose');
const activityDetailSchema=new mongoose.Schema(
    {
        habitName:{
            type:String,
            returied:true
        },
        Datedtl:{
            type:Date,
            returied:true

        },
        undone:{
            type:String,
            requried:true
        }

    }
);
const ActivityDetail=mongoose.model('ActivityDetail',activityDetailSchema);
module.exports=ActivityDetail;